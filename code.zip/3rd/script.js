const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');

let displayValue = '';
let operator = '';
let firstValue = '';
let secondValue = '';
let result = '';

buttons.forEach(button => {
    button.addEventListener('click', () => {
        const value = button.textContent;

        if (value === 'C') {
            displayValue = '';
            firstValue = '';
            secondValue = '';
            operator = '';
            result = '';
            display.textContent = '0';
        } else if (value === '←') {
            displayValue = displayValue.slice(0, -1);
            display.textContent = displayValue || '0';
        } else if (value === '/' || value === '*' || value === '-' || value === '+') {
            if (operator) {
                calculate();
            }
            firstValue = displayValue;
            operator = value;
            displayValue = '';
        } else if (value === '=') {
            secondValue = displayValue;
            calculate();
            operator = '';
        } else if (value === '.' && !displayValue.includes('.')) {
            displayValue += value;
            display.textContent = displayValue;
        } else if (!isNaN(value)) {
            displayValue += value;
            display.textContent = displayValue;
        }
    });
});

function calculate() {
    if (operator && firstValue !== '') {
        switch (operator) {
            case '/':
                result = parseFloat(firstValue) / parseFloat(secondValue);
                break;
            case '*':
                result = parseFloat(firstValue) * parseFloat(secondValue);
                break;
            case '-':
                result = parseFloat(firstValue) - parseFloat(secondValue);
                break;
            case '+':
                result = parseFloat(firstValue) + parseFloat(secondValue);
                break;
        }
        display.textContent = result;
        firstValue = result;
        displayValue = '';
    }
}
